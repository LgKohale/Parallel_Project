package com.cg.jpa.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.cg.jpa.dao.BankDaoImpl;
import com.cg.jpa.entity.Bank;
import com.cg.jpa.entity.Transaction;
import com.cg.jpa.exception.BankException;
import com.cp.jpa.service.BankServiceImpl;

public class BankDaoImplTest {

	Bank bank=null;
	BankServiceImpl service= null;
	BankDaoImpl dao= null;
	@Test
	public void testAddCustomer() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		 bank.setCustName("Tom");
		 bank.setCustAge(23);
		 bank.setEmailid("ggg@gmail.com");
		 bank.setAddress("Banglore");
		 bank.setBalance(10000);
		 bank.setIdProof("123789456789");
		 bank.setCustMobNo("8989565623");
		 bank.setAccountNo(11111);
		 bank.setAccPin(4522);
		 int acc=service.addCustomer(bank);
		 System.out.println(acc);
		assertEquals(11111,acc);
		 
	}

	@Test
	public void testShowBalance() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		double balance=service.showBalance(11111, 4522);
		assertEquals(100, balance, 0);
	}

	@Test
	public void testDepositAmount() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		double balance= service.depositAmount(11111, 4522, 100);
		assertEquals(400, balance,0);
	}

	@Test
	public void testWithdrawAmount() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		double balance= service.withdrawAmount(11111, 4522, 100);
		assertEquals(300, balance, 0);
	}

	@Test
	public void testFundTransfer() throws BankException {
		bank= new Bank();
		service=new BankServiceImpl();
		double balance=service.FundTransfer(1029456, 3344, 11111, 100);
		System.out.println(balance);
		assertEquals(900, balance, 0);
	}

	@Test
	public void testPrintTransaction() throws BankException {
		int flag;
		bank= new Bank();
		service=new BankServiceImpl();
		List<Transaction> custList= service.printTransaction(11111);
		//System.out.println(custList);
		if(custList!=null){
			flag=1;
		}else{
			flag=0;
		}
		assertEquals("Success", 1, flag);
	}

}
