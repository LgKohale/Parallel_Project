package com.cg.jpa.exception;

public class BankException extends Exception{

	private String status;
	public BankException(String status) {
		super(status);
	}
	public String getStatus() {
		return status;
	}
	
	public BankException(){
		this.status="Unable to perform operations";
	}
	@Override
	public String toString() {
		return "BankException [status=" + status + "]";
	}
	
	

}
