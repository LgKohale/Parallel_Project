package com.cp.jpa.service;

import java.util.List;

import com.cg.jpa.entity.Bank;
import com.cg.jpa.entity.Transaction;
import com.cg.jpa.exception.BankException;


public interface BankService {
	public int addCustomer(Bank bean)throws BankException;
	//public Map<Integer,Ba> getAll();
	
	public double showBalance(int acc, int apin)throws BankException;
	public double depositAmount(int acc1, int apin1, double deposit)throws BankException;
	public double withdrawAmount(int acc2,int apin2, double withdraw)throws BankException;
	public double FundTransfer(int acc3,int apin3, int acc4, double amount)throws BankException;
	public List<Transaction> printTransaction(int account) throws BankException;
}
