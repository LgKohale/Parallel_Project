package com.cg.jpa.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.cg.jpa.entity.Bank;
import com.cg.jpa.entity.Transaction;
import com.cg.jpa.exception.BankException;
import com.cp.jpa.service.BankService;
import com.cp.jpa.service.BankServiceImpl;

public class Client {
	private static BankService service= new BankServiceImpl();
	private static Scanner sc= new Scanner(System.in);
	private static BankServiceImpl serv= new BankServiceImpl();

	public static void main(String[] args) throws BankException{
		while(true){
			System.out.println("===============================");
			System.out.println("===========Welcome=============");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit Amount");
			System.out.println("4.Withdraw Amount");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transaction");
			System.out.println("7.Exit");
			System.out.println("===============================");
			System.out.println("Enter your Choice");
			int choice = sc.nextInt();
			
			switch(choice){
			case 1:
				
				Bank bank= new Bank();
				getCustomerDetails(bank);
				//service.validation(bank);
				int caccount=addCustomer(bank);
				System.out.println("------------------------------------");
				System.out.println("Your account no. is :"+caccount);
				System.out.println("Account pin is :"+bank.getAccPin());
				
				System.out.println(bank);
				System.out.println("===============================");
				System.out.println("===============================");
				break;
				
			case 2:
				System.out.println("Enter Account number: ");
				int acc1= sc.nextInt();
				System.out.println("Enter Account pin: ");
				int pin1= sc.nextInt();
				double balance=service.showBalance(acc1, pin1);
				System.out.println("------------------------------------");
				System.out.println("Your Account Balance is: "+balance);
				System.out.println("===============================");
				System.out.println("===============================");
				break;
				
			case 3:
				System.out.println("Enter Account number: ");
				int acc2= sc.nextInt();
				System.out.println("Enter Account pin: ");
				int pin2= sc.nextInt();
				Boolean Valid= serv.validAccount(acc2, pin2);
				if(Valid){
					System.out.println("Enter the amount to deposit: ");
					double deposit= sc.nextDouble();
					double accbal=service.depositAmount(acc2, pin2,deposit);
					System.out.println("------------------------------------");
					System.out.println("Your Account balance is: "+accbal);
				}else{
					System.out.println("Invalid Account Credentials..");
				}
				System.out.println("===============================");
				System.out.println("===============================");
				break;
				
			case 4:
				System.out.println("Enter Account number: ");
				int acc3= sc.nextInt();
				System.out.println("Enter Account pin: ");
				int pin3= sc.nextInt();
				Boolean valid= serv.validAccount(acc3, pin3);
				if(valid){
					System.out.println("Enter the amount to withdraw: ");
					double withdraw= sc.nextDouble();
					double accbal= service.withdrawAmount(acc3, pin3, withdraw);
					System.out.println("------------------------------------");
					System.out.println("Your Account balance is: "+accbal);
				}else{
					System.out.println("Invalid Account Credentials..");
				}
				System.out.println("===============================");
				System.out.println("===============================");
				break;
				
			case 5:
				System.out.println("Enter first Account number: ");
				int acc4=sc.nextInt();
				System.out.println("Enter Account pin: ");
				int pin4=sc.nextInt();
				
				Boolean valid1= serv.validAccount(acc4, pin4);
				if(valid1){
					System.out.println("Enter second Account number: ");
					int acc5= sc.nextInt();
					Boolean valid2= serv.valida(acc5);
					if(valid2){
						System.out.println("Enter the amount to transfer: ");
						double amount=sc.nextDouble();
						double balf=service.FundTransfer(acc4, pin4, acc5, amount);
						System.out.println("------------------------------------");
						System.out.println("Your Account balance after Fund Transfer is :" +balf);
					}else{
						System.out.println("Account dosen't Exist: "+acc5);
					}
				}else{
					System.out.println("Account dosen't Exist: "+acc4);
				}
				System.out.println("===============================");
				System.out.println("===============================");
				break;
				
			case 6:
				System.out.println("Enter the Account number: ");
				int account=sc.nextInt();
				List<Transaction> list= service.printTransaction(account);
				showDetails(list);
				System.out.println("===============================");
				System.out.println("===============================");
				
				break;
				
			case 7:
				System.exit(0);
			}
		} 
	}

	private static void showDetails(List<Transaction> list) {
		Iterator<Transaction> it= list.iterator();
		while(it.hasNext()){
			
			System.out.println(it.next());
			
		}
		System.out.println("===============================");
		System.out.println("===============================");
	}

	private static int addCustomer(Bank bank) {
		int create=0;
		try {
			create=service.addCustomer(bank);
			
		} catch (BankException e) {
			e.printStackTrace();
		}
		return create;
	}

	private static void getCustomerDetails(Bank bank) {
		System.out.println("Enter Customer name: ");
		String custName=sc.next();
		boolean validname=serv.validName(custName);
		String vname;
		boolean validn;
		if(!validname){
			do{
				System.out.println("Enter name with Init-caps(ex:Tom): ");
				System.out.println("Enter your Name: ");
				vname= sc.next();
				validn = serv.validName(vname);
			}while(!validn);
			bank.setCustName(vname);
		}
		else
			bank.setCustName(custName);
		
		
		System.out.println("Enter your Address: ");
		bank.setAddress(sc.next());
		
		System.out.println("Enter AAdhar Card number: ");
		String idProof = sc.next();
		boolean validac=serv.validAdhar(idProof);
		boolean validaa;
		String proof;
		if(!validac){
			do{
				System.out.println("Enter 12 digit Aadhar card number: ");
				System.out.println("Enter the Id number " );
				proof=sc.next();
				validaa= serv.validAdhar(proof);
			}while(!validaa);
			bank.setIdProof(proof);
		}else
			bank.setIdProof(idProof);
		
		
		System.out.println("Enter mobile number: ");
		String custMobNo = sc.next();
		boolean validm= serv.validMobileaNo(custMobNo);
		boolean Validm;
		String mob;
		if(!validm){
			do{
				System.out.println("Enter correct 10 digit mobile number: ");
				mob=sc.next();
				Validm= serv.validMobileaNo(mob);
			}while(!Validm);
			bank.setCustMobNo(mob);
		}else
			bank.setCustMobNo(custMobNo);
		
		
		System.out.println("Enter customer age: ");
		int custAge = sc.nextInt();
		boolean validage= serv.validAge(custAge);
		boolean Validage;
		int age;
		if(!validage){
			do{
				System.out.println("Enter valid age :");
				age=sc.nextInt();
				Validage=serv.validAge(age);
			}while(!Validage);
			bank.setCustAge(age);
		}else
			bank.setCustAge(custAge);
		
		
		System.out.println("Enter email id: ");
		String emailid = sc.next();
		boolean isvalid = serv.validEmail(emailid);
		boolean validid;
		String emailid1;
		if (!isvalid) {
			do {
				System.out.println("Type correct email Id");
				System.out.println("Enter your email id:");
				emailid1 = sc.next();
				validid = serv.validEmail(emailid1);

			} while (!validid);
			bank.setEmailid(emailid1);
		}else
			bank.setEmailid(emailid);
		bank.setBalance(0.0);
		Random rd1 = new Random();
		int accountNo = 1000000 + rd1.nextInt(900000);
		bank.setAccountNo(accountNo);
		Random rd2 = new Random();
		int accPin = 1000 + rd2.nextInt(9000);
		bank.setAccPin(accPin);	
		System.out.println("Enter the minimum balance you want to keep: ");
		bank.setBalance(sc.nextDouble());
		
	}

}
